from flask import render_template, request, redirect, url_for, flash, jsonify
from models import db, Product, Sale
from datetime import datetime, timedelta
import json
from statisticsgraph import generate_sales_chart, generate_product_chart, generate_stock_chart

def register_routes(app):
    @app.route('/')
    def index():
        # Récupérer les statistiques pour le tableau de bord
        products_count = Product.query.count()
        products_low_stock = Product.query.filter(Product.stock < 5).count()
        # Ventes des 30 derniers jours
        thirty_days_ago = datetime.now() - timedelta(days=30)
        recent_sales = Sale.query.filter(Sale.sale_date >= thirty_days_ago).all()
        total_sales = len(recent_sales)
        total_revenue = sum(sale.quantity * sale.sale_price for sale in recent_sales)
        # Top 5 des produits les plus vendus
        top_products = db.session.query(
            Product.name, 
            db.func.sum(Sale.quantity).label('total_quantity')
        ).join(Sale).group_by(Product.id).order_by(db.desc('total_quantity')).limit(5).all()
        # Graphiques pour le tableau de bord
        sales_chart = generate_sales_chart()
        product_chart = generate_product_chart()
        stock_chart = generate_stock_chart()
        return render_template('index.html',  products_count=products_count, products_low_stock=products_low_stock, total_sales=total_sales, total_revenue=total_revenue, top_products=top_products, sales_chart=sales_chart, product_chart=product_chart, stock_chart=stock_chart)
    
    
    # Gestion des produits
    @app.route('/products')
    def products_list():
        products = Product.query.all()
        return render_template('products/index.html', products=products)
    
    @app.route('/products/add', methods=['GET', 'POST'])
    def add_product():
        if request.method == 'POST':
            name = request.form.get('name')
            description = request.form.get('description')
            price = float(request.form.get('price'))
            stock = int(request.form.get('stock'))
            product = Product(name=name, description=description, price=price, stock=stock)
            db.session.add(product)
            db.session.commit()
            flash('Produit ajouté avec succès!', 'success')
            return redirect(url_for('products_list'))
        return render_template('products/add.html')
    
    @app.route('/products/edit/<int:id>', methods=['GET', 'POST'])
    def edit_product(id):
        product = Product.query.get_or_404(id)
        if request.method == 'POST':
            product.name = request.form.get('name')
            product.description = request.form.get('description')
            product.price = float(request.form.get('price'))
            product.stock = int(request.form.get('stock'))
            db.session.commit()
            flash('Produit mis à jour avec succès!', 'success')
            return redirect(url_for('products_list'))
        return render_template('products/edit.html', product=product)
    
    @app.route('/products/delete/<int:id>', methods=['POST'])
    def delete_product(id):
        product = Product.query.get_or_404(id)
        db.session.delete(product)
        db.session.commit()
        flash('Produit supprimé avec succès!', 'success')
        return redirect(url_for('products_list'))
    
    # Gestion des ventes
    @app.route('/sales')
    def sales_list():
        sales = Sale.query.order_by(Sale.sale_date.desc()).all()
        return render_template('sales/index.html', sales=sales)
    
    @app.route('/sales/add', methods=['GET', 'POST'])
    def add_sale():
        products = Product.query.all()
        if request.method == 'POST':
            product_id = int(request.form.get('product_id'))
            quantity = int(request.form.get('quantity'))
            product = Product.query.get_or_404(product_id)
            if product.stock < quantity:
                flash('Stock insuffisant!', 'danger')
                return redirect(url_for('add_sale'))
            sale_price = float(request.form.get('sale_price') or product.price)
            sale = Sale(
                product_id=product_id,
                quantity=quantity,
                sale_price=sale_price
            )
            db.session.add(sale)
            db.session.commit()
            product.stock -= quantity
            db.session.commit()
            flash('Vente enregistrée avec succès!', 'success')
            return redirect(url_for('sales_list'))
        return render_template('sales/add.html', products=products)
    
    @app.route('/sales/details/<int:id>')
    def sale_details(id):
        sale = Sale.query.get_or_404(id)
        return render_template('sales/details.html', sale=sale)

    # API pour les statistiques
    @app.route('/api/statistics')
    def statistics_api():
        # Récupérer la période demandée (semaine, mois, année, ou tout)
        period = request.args.get('period', 'month')
        if period == 'week':
            start_date = datetime.now() - timedelta(days=7)
        elif period == 'month':
            start_date = datetime.now() - timedelta(days=30)
        elif period == 'year':
            start_date = datetime.now() - timedelta(days=365)
        else:
            start_date = datetime(2000, 1, 1)
        sales = Sale.query.filter(Sale.sale_date >= start_date).all()
        total_sales = len(sales)
        total_revenue = sum(sale.quantity * sale.sale_price for sale in sales)

        top_products = db.session.query(
            Product.name, 
            db.func.sum(Sale.quantity).label('total_quantity')
        ).join(Sale).filter(Sale.sale_date >= start_date).group_by(Product.id).order_by(db.desc('total_quantity')).limit(5).all()
        top_products_data = [{'name': product[0], 'total': product[1]} for product in top_products]
        return jsonify({
            'total_sales': total_sales,
            'total_revenue': total_revenue,
            'top_products': top_products_data
        })

    @app.route('/api/sales_chart')
    def sales_chart_api():
        # Récupérer la période demandée (semaine, mois, année, ou tout)
        period = request.args.get('period', 'month')
        end_date = datetime.now()
        if period == 'week':
            start_date = end_date - timedelta(days=7)
            date_format = '%d/%m' 
            delta = timedelta(days=1) 
        elif period == 'month':
            start_date = end_date - timedelta(days=30)
            date_format = '%d/%m' 
            delta = timedelta(days=1)
        elif period == 'year':
            start_date = end_date - timedelta(days=365)
            date_format = '%m/%Y'  
            delta = timedelta(days=30) 
        else:  
            first_sale = Sale.query.order_by(Sale.sale_date.asc()).first()
            if first_sale:
                start_date = first_sale.sale_date
                date_format = '%m/%Y'
                delta = timedelta(days=90) 
            else:
                start_date = end_date - timedelta(days=365)  
                date_format = '%m/%Y'  
                delta = timedelta(days=90)  
        labels = []
        data = []
   
        current_date = start_date
        while current_date <= end_date:
            labels.append(current_date.strftime(date_format))
            if period in ['week', 'month']:
                next_date = current_date + timedelta(days=1)
                sales_count = Sale.query.filter(
                    Sale.sale_date >= current_date,
                    Sale.sale_date < next_date
                ).count()
            else:
                next_date = current_date + delta
                sales_count = Sale.query.filter(
                    Sale.sale_date >= current_date,
                    Sale.sale_date < next_date
                ).count()
            data.append(sales_count)
            current_date = next_date
        if len(labels) > 20 and period == 'year':
            grouped_labels = []
            grouped_data = []
            for i in range(0, len(labels), 3): 
                if i < len(labels):
                    grouped_labels.append(labels[i])
                    grouped_data.append(sum(data[i:i+3]))
            labels = grouped_labels
            data = grouped_data
    
        return jsonify({
            'labels': labels,
            'data': data
        })
    @app.route('/statistics')
    def statistics():
        return render_template('statistics.html')