import os
from datetime import timedelta

class Config:
    # Configuration générale
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'clé-secrète-à-changer-en-production'
    PERMANENT_SESSION_LIFETIME = timedelta(minutes=60)
    
    # Configuration MySQL
    MYSQL_HOST = os.environ.get('MYSQL_HOST') or 'localhost'
    MYSQL_USER = os.environ.get('MYSQL_USER') or 'root'
    MYSQL_PASSWORD = os.environ.get('MYSQL_PASSWORD') or '1234'
    MYSQL_DB = os.environ.get('MYSQL_DB') or 'dbinventory'
    
    # Configuration de l'upload de fichiers
    UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static/uploads')
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}