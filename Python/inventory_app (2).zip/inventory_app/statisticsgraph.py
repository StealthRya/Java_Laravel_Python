import io
import base64
import matplotlib
matplotlib.use('Agg') 
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
from models import db, Sale, Product

def generate_sales_chart():
    """Génère un graphique des ventes sur les 30 derniers jours"""
    end_date = datetime.now()
    start_date = end_date - timedelta(days=30)
    dates = []
    date = start_date
    while date <= end_date:
        dates.append(date.strftime('%Y-%m-%d'))
        date += timedelta(days=1)
    sales_data = []
    for date_str in dates:
        date_obj = datetime.strptime(date_str, '%Y-%m-%d')
        next_day = date_obj + timedelta(days=1)
        sales_count = Sale.query.filter(
            Sale.sale_date >= date_obj,
            Sale.sale_date < next_day
        ).count()
        sales_data.append(sales_count)
    plt.figure(figsize=(10, 5))
    plt.plot(dates, sales_data, marker='o', linestyle='-', color='blue')
    plt.title('Nombre de ventes sur les 30 derniers jours')
    plt.xlabel('Date')
    plt.ylabel('Nombre de ventes')
    plt.xticks(rotation=45)
    plt.tight_layout()
    # Convertir le graphique en image encodée en base64
    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    graph_url = base64.b64encode(img.getvalue()).decode()
    plt.close()
    return 'data:image/png;base64,{}'.format(graph_url)

def generate_product_chart():
    """Génère un graphique des produits les plus vendus"""
    top_products = db.session.query(
        Product.name, 
        db.func.sum(Sale.quantity).label('total_quantity')
    ).join(Sale).group_by(Product.id).order_by(db.desc('total_quantity')).limit(10).all()
    product_names = [product[0] for product in top_products]
    product_quantities = [product[1] for product in top_products]
    plt.figure(figsize=(10, 5))
    plt.bar(product_names, product_quantities, color='green')
    plt.title('Top 10 des produits les plus vendus')
    plt.xlabel('Produit')
    plt.ylabel('Quantité vendue')
    plt.xticks(rotation=45)
    plt.tight_layout()
    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    graph_url = base64.b64encode(img.getvalue()).decode()
    plt.close()
    return 'data:image/png;base64,{}'.format(graph_url)

def generate_stock_chart():
    """Génère un graphique des niveaux de stock actuels"""
    products = Product.query.all()
    product_names = [product.name for product in products]
    stock_levels = [product.stock for product in products]
    plt.figure(figsize=(10, 5))
    plt.barh(product_names, stock_levels, color='red')
    plt.title('Niveaux de stock actuels')
    plt.xlabel('Quantité en stock')
    plt.ylabel('Produit')
    plt.tight_layout()
    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    graph_url = base64.b64encode(img.getvalue()).decode()
    plt.close()
    return 'data:image/png;base64,{}'.format(graph_url)

def calculate_sales_statistics(period='month'):
    """Calcule les statistiques de vente pour une période donnée"""
    if period == 'week':
        start_date = datetime.now() - timedelta(days=7)
    elif period == 'month':
        start_date = datetime.now() - timedelta(days=30)
    elif period == 'year':
        start_date = datetime.now() - timedelta(days=365)
    else:  
        start_date = datetime(1900, 1, 1)
    sales = Sale.query.filter(Sale.sale_date >= start_date).all()
    total_sales = len(sales)
    total_revenue = sum(sale.quantity * sale.sale_price for sale in sales)
    top_products = db.session.query(
        Product.name, 
        db.func.sum(Sale.quantity).label('total_quantity')
    ).join(Sale).filter(Sale.sale_date >= start_date).group_by(Product.id).order_by(db.desc('total_quantity')).limit(5).all()
    return { 'total_sales': total_sales,'total_revenue': total_revenue,'top_products': top_products
    }