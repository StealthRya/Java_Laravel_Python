document.addEventListener('DOMContentLoaded', function() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    setTimeout(function() {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);
    const priceElements = document.querySelectorAll('.price-format');
    priceElements.forEach(function(element) {
        const price = parseFloat(element.textContent);
        if (!isNaN(price)) {
            element.textContent = price.toFixed(2) + ' FCFA';
        }
    });
    const dateInputs = document.querySelectorAll('.date-input');
    if (dateInputs.length > 0 && typeof flatpickr !== 'undefined') {
        dateInputs.forEach(function(input) {
            flatpickr(input, {
                dateFormat: "d/m/Y",
                locale: "fr"
            });
        });
    }
    const currentLocation = window.location.pathname;
    const navLinks = document.querySelectorAll('.navbar-nav .nav-link');
    navLinks.forEach(function(link) {
        const linkPath = link.getAttribute('href');
        if (currentLocation === linkPath) {
            link.classList.add('active');
        }
    });
    // Confirmation pour les actions de suppression
    const deleteButtons = document.querySelectorAll('.delete-confirm');
    deleteButtons.forEach(function(button) {
        button.addEventListener('click', function(e) {
            if (!confirm('Êtes-vous sûr de vouloir supprimer cet élément ?')) {
                e.preventDefault();
            }
        });
    });

    // Initialiser la recherche dans les tableaux
    const searchInputs = document.querySelectorAll('.table-search');
    searchInputs.forEach(function(input) {
        input.addEventListener('keyup', function() {
            const searchText = this.value.toLowerCase();
            const tableId = this.getAttribute('data-table');
            const table = document.getElementById(tableId);
            
            if (table) {
                const rows = table.querySelectorAll('tbody tr');
                
                rows.forEach(function(row) {
                    let shouldShow = false;
                    const cells = row.querySelectorAll('td');
                    
                    cells.forEach(function(cell) {
                        if (cell.textContent.toLowerCase().includes(searchText)) {
                            shouldShow = true;
                        }
                    });
                    
                    row.style.display = shouldShow ? '' : 'none';
                });
            }
        });
    });
    // Tri des tableaux
    const sortableHeaders = document.querySelectorAll('th.sortable');
    sortableHeaders.forEach(function(header) {
        header.addEventListener('click', function() {
            const table = header.closest('table');
            const index = Array.from(header.parentNode.children).indexOf(header);
            const isAscending = header.classList.contains('asc');
            table.querySelectorAll('th.sortable').forEach(function(th) {
                th.classList.remove('asc', 'desc');
            });
            header.classList.add(isAscending ? 'desc' : 'asc');
            const rows = Array.from(table.querySelectorAll('tbody tr'));
            rows.sort(function(a, b) {
                const aValue = a.children[index].textContent.trim();
                const bValue = b.children[index].textContent.trim();  
                const aNum = parseFloat(aValue);
                const bNum = parseFloat(bValue);
                
                if (!isNaN(aNum) && !isNaN(bNum)) {
                    return isAscending ? bNum - aNum : aNum - bNum;
                } else {
                    return isAscending ? 
                        bValue.localeCompare(aValue, 'fr') : 
                        aValue.localeCompare(bValue, 'fr');
                }
            });
            const tbody = table.querySelector('tbody');
            rows.forEach(function(row) {
                tbody.appendChild(row);
            });
        });
    });
});


