from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from config import Config
from models import db
from routes import register_routes
import os

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql://{app.config['MYSQL_USER']}:{app.config['MYSQL_PASSWORD']}@{app.config['MYSQL_HOST']}/{app.config['MYSQL_DB']}"
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    
    db.init_app(app)
    register_routes(app)

    @app.template_filter('date_format')
    def date_format(value, format='%d/%m/%Y'):
        if value:
            return value.strftime(format)
        return ""
    # Fonction pour tronquer les textes longs dans les templates
    @app.template_filter('truncate')
    def truncate_filter(text, length=100, end='...'):
        if not text:
            return ""
        if len(text) <= length:
            return text
        return text[:length] + end 
    return app
if __name__ == '__main__':
    app = create_app()
    # Créer les tables si elles n'existent pas
    with app.app_context():
        db.create_all()
    app.run(debug=True)